package calculators;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.concurrent.Semaphore;

@RestController
@RequestMapping("/movie")
public class MovieBookingController {

    private static final int TOTAL_SEATS = 5;
    private final Semaphore seatSemaphore = new Semaphore(TOTAL_SEATS);
    private int nextSeat = 1; // Counter to track the next available seat

    @GetMapping("/book")
    public String bookSeat() {
        try {
            // Acquire a permit from the semaphore
            seatSemaphore.acquire();

            // Critical section: Access the shared resource (book a seat)
            int bookedSeat = bookSeatInternal();

            // Print thread and seat booking information
            System.out.println("Thread " + Thread.currentThread().getId() +
                    " acquired a permit and booked Seat " + bookedSeat);

            return "Seat " + bookedSeat + " booked successfully.";
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return "Error booking seat.";
        }
//        finally {
//            // Release the permit back to the semaphore
//            seatSemaphore.release();
//
//            // Print thread information after releasing the permit
//            System.out.println("Thread " + Thread.currentThread().getId() +
//                    " released a permit.");
//        }
    }

    private synchronized int bookSeatInternal() {
        // Simulate some processing
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }

     // Get the next available seat and increment the counter
        int bookedSeat = nextSeat++;
        return bookedSeat;
    }
}
